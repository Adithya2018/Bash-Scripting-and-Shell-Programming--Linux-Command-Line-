#!/bin/bash -vx
TEST_VAR="test"
echo "$TEST_VAR"
