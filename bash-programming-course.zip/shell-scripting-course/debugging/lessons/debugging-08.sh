#!/bin/bash

DEBUG=true
$DEBUG && echo "Debug mode ON."

