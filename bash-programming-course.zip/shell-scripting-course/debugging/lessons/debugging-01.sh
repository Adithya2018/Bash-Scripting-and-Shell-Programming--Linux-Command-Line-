#!/bin/bash -x

TEST_VAR="test"
echo "$TEST_VAR"
