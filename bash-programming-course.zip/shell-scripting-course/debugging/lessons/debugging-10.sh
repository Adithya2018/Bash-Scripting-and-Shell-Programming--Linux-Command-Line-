#!/bin/bash

DEBUG=true

# This will not execute because DEUBG=true
$DEBUG || echo "Debug mode OFF."

