#!/bin/bash -ex

FILE_NAME="/not/here"
ls $FILE_NAME
echo $FILE_NAME
