#!/usr/bin/python
print "This is a Python script."
