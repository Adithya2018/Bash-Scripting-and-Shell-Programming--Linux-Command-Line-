#!/bin/csh
echo "This script uses csh as the interpreter."
