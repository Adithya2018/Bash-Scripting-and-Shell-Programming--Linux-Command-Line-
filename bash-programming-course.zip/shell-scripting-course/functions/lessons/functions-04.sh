#!/bin/bash

function hello() {
    echo "Hello $1"
}

hello Jason
